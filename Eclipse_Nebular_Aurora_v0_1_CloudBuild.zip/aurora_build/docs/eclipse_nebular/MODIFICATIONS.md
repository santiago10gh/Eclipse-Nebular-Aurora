# Eclipse Nebular Aurora — source modification log

Target: Minecraft Bedrock 1.26.62 / Android / MB Loader.

This is a source-based derivative working copy of Newb X Legacy. The upstream LICENSE file is preserved.

## Initial Aurora color changes
- Gamma lowered slightly: 1.33 -> 1.30
- Saturation enabled at 1.06 (subtle)
- Sunlight intensity lowered slightly: 3.3 -> 3.1
- Dawn sunlight shifted toward violet
- Dawn horizon and edge colors shifted toward purple
- Day sky colors moderated toward cyan-blue
- Night sky colors shifted toward blue-violet
- Moonlight color shifted toward blue-violet
- Water tint shifted away from green toward blue
- Aurora effect colors shifted toward cyan and violet

## Conservative performance choices
No new expensive effects were enabled. Existing source behavior and effects remain otherwise unchanged at this stage. The shader has not been compiled or tested in-game yet.

## Build environment requirements from upstream README
- Python 3.11+
- Lazurite 0.12.0
- Rich 14+ (upstream requirements pins Rich 15.0.0)
- packaging >=25.0
- Run build setup (`build.sh setup` or Windows `build.bat setup`)
- Compile materials (`build.sh mats -p android`)
- Build pack (`build.sh pack -p android`)

The upstream setup step downloads shaderc and material source data. It could not be completed in this environment because network DNS access is unavailable.

## Next step
Run upstream setup in a connected computer/environment, then compile the Android profile. Review and fix build errors, export a `.mcpack`, and test with MB Loader on the target phone. This ZIP contains source/configuration only; it does not contain compiled shader materials or a functional shader pack.
