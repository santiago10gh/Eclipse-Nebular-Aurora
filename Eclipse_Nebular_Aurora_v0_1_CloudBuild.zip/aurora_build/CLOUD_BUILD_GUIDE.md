# Eclipse Nebular Aurora v0.1 — Cloud build (GitHub Actions)

This source tree includes `.github/workflows/eclipse-nebular-android.yml` to compile the Android ESSL pack in GitHub Actions.

## Run the build
1. Create a **private** GitHub repository and upload this source tree (not the ZIP file as a single file; extract it first).
2. Confirm the workflow file is in `.github/workflows/` in the repository.
3. Open the repository's **Actions** tab.
4. Select **Eclipse Nebular Aurora Android Build**.
5. Press **Run workflow** and leave version label as `1` (or choose another integer).
6. Wait for the job to finish. A successful run should provide an artifact named `Eclipse-Nebular-Aurora-Android`.
7. Download that artifact and inspect the pack before installing it in Minecraft/MB Loader.

This workflow does not guarantee compatibility with Minecraft Bedrock 1.26.62 or MB Loader; that must be tested in-game. If the build fails, preserve the Actions log for troubleshooting.
