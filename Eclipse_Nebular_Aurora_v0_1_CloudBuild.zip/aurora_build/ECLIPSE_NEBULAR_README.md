# Eclipse Nebular — Aurora v0.1.0 (source working copy)

This is a customized source working copy based on Newb X Legacy.

**Important:** This source has not been compiled. It is not yet a functioning shader package.

Target: Minecraft Bedrock 1.26.62 on Android via MB Loader.

See `docs/eclipse_nebular/MODIFICATIONS.md` for the first color configuration changes and build blockers.

Upstream project: https://github.com/devendrn/newb-x-mcbe
The upstream MIT LICENSE is preserved.
